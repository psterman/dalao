/*
 * Copyright (c) 2022, Oracle and/or its affiliates. All rights reserved.
 * ORACLE PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 */
package java.lang.classfile.instruction;

import java.lang.classfile.CodeElement;
import java.lang.classfile.CodeModel;
import java.lang.classfile.constantpool.ClassEntry;
import java.lang.classfile.Instruction;
import jdk.internal.classfile.impl.AbstractInstruction;
import jdk.internal.javac.PreviewFeature;

/**
 * Models a {@code new} instruction in the {@code code} array of a {@code Code}
 * attribute.  Delivered as a {@link CodeElement} when traversing the elements
 * of a {@link CodeModel}.
 *
 * @since 22
 */
@PreviewFeature(feature = PreviewFeature.Feature.CLASSFILE_API)
public sealed interface NewObjectInstruction extends Instruction
        permits AbstractInstruction.BoundNewObjectInstruction, AbstractInstruction.UnboundNewObjectInstruction {

    /**
     * {@return the type of object to create}
     */
    ClassEntry className();

    /**
     * {@return a new object instruction}
     *
     * @param className the type of object to create
     */
    static NewObjectInstruction of(ClassEntry className) {
        return new AbstractInstruction.UnboundNewObjectInstruction(className);
    }
}
